Aletheo Wallet.

by Sam Porter.

So at first it was Form History Control II by Stephan Mahieu, I thought that's the most autistic browser extension I could find. But it's almost no code left from him. His only code left is in collectFormData.js which was still quite heavily and sloppily(for now) modified. I however kept some of his architecture, even if by cryptowallet standards it's not secure. Anyway, this wallet is not supposed to be used to keep any funds as of yet, it's a brick, which tracks certain text areas and sends that to the blockchain.
Will be made secure eventually.